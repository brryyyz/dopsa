import json
from pathlib import Path

DATA_FILE = Path(__file__).with_name("students.json")
MIN_GRADE = 2
MAX_GRADE = 5


def load_students():
    """Загружает студентов из JSON. При проблеме начинает с пустого списка."""
    if not DATA_FILE.exists():
        return []

    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)

        if not isinstance(data, list):
            raise ValueError("Корневое значение JSON должно быть списком.")

        students = []
        for item in data:
            if not isinstance(item, dict):
                continue
            name = item.get("name")
            group = item.get("group")
            grades = item.get("grades", [])

            if not isinstance(name, str) or not name.strip():
                continue
            if not isinstance(group, str) or not group.strip():
                continue
            if not isinstance(grades, list):
                grades = []

            valid_grades = []
            for grade in grades:
                if not isinstance(grade, dict):
                    continue
                subject = grade.get("subject")
                value = grade.get("value")
                if (
                    isinstance(subject, str)
                    and subject.strip()
                    and isinstance(value, int)
                    and not isinstance(value, bool)
                    and MIN_GRADE <= value <= MAX_GRADE
                ):
                    valid_grades.append(
                        {"subject": subject.strip(), "value": value}
                    )

            students.append({
                "name": name.strip(),
                "group": group.strip(),
                "grades": valid_grades
            })
        return students
    except (OSError, json.JSONDecodeError, ValueError) as error:
        print(f"Не удалось загрузить данные: {error}")
        print("Программа продолжит работу с пустым списком.")
        return []


def save_students(students):
    """Сохраняет данные в JSON."""
    try:
        with DATA_FILE.open("w", encoding="utf-8") as file:
            json.dump(students, file, ensure_ascii=False, indent=4)
    except OSError as error:
        print(f"Ошибка сохранения файла: {error}")


def student_average(student):
    grades = student["grades"]
    if not grades:
        return None
    return sum(item["value"] for item in grades) / len(grades)


def input_nonempty(prompt):
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("Поле не должно быть пустым.")


def choose_student(students):
    if not students:
        print("Список студентов пуст.")
        return None

    for index, student in enumerate(students, 1):
        print(f"{index}. {student['name']} — группа {student['group']}")

    try:
        number = int(input("Номер студента: "))
        if 1 <= number <= len(students):
            return students[number - 1]
    except ValueError:
        pass

    print("Некорректный номер.")
    return None


def add_student(students):
    name = input_nonempty("ФИО студента: ")
    group = input_nonempty("Номер группы: ")
    students.append({"name": name, "group": group, "grades": []})
    save_students(students)
    print("Студент добавлен.")


def show_students(students):
    if not students:
        print("Список студентов пуст.")
        return

    print("\nСписок студентов:")
    for index, student in enumerate(students, 1):
        average = student_average(student)
        average_text = f"{average:.2f}" if average is not None else "нет оценок"
        print(
            f"{index}. {student['name']} | группа: {student['group']} "
            f"| средний балл: {average_text}"
        )


def search_student(students):
    query = input_nonempty("Введите ФИО или часть имени: ").casefold()
    matches = [s for s in students if query in s["name"].casefold()]

    if not matches:
        print("Студенты не найдены.")
        return

    for student in matches:
        average = student_average(student)
        average_text = f"{average:.2f}" if average is not None else "нет оценок"
        print(
            f"{student['name']} | группа: {student['group']} "
            f"| средний балл: {average_text}"
        )


def add_grade(students):
    student = choose_student(students)
    if student is None:
        return

    subject = input_nonempty("Дисциплина: ")
    while True:
        try:
            value = int(input(f"Оценка ({MIN_GRADE}-{MAX_GRADE}): "))
            if MIN_GRADE <= value <= MAX_GRADE:
                break
            print(f"Оценка должна быть от {MIN_GRADE} до {MAX_GRADE}.")
        except ValueError:
            print("Введите целое число.")

    student["grades"].append({"subject": subject, "value": value})
    save_students(students)
    print("Оценка добавлена.")


def show_student_grades(students):
    student = choose_student(students)
    if student is None:
        return

    print(f"\nОценки: {student['name']}")
    if not student["grades"]:
        print("Оценок пока нет.")
        return

    values = []
    for item in student["grades"]:
        print(f"- {item['subject']}: {item['value']}")
        values.append(item["value"])

    print(f"Средний балл: {sum(values) / len(values):.2f}")
    print(f"Высшая оценка: {max(values)}")
    print(f"Низшая оценка: {min(values)}")


def group_analytics(students):
    graded = [(s, student_average(s)) for s in students if student_average(s) is not None]
    if not graded:
        print("Пока нет студентов с оценками.")
        return

    average = sum(value for _, value in graded) / len(graded)
    excellent = sum(1 for _, value in graded if value >= 4.5)
    failing = sum(1 for _, value in graded if value < 3.0)

    print(f"Средний балл группы (по студентам с оценками): {average:.2f}")
    print(f"Отличники (средний балл от 4.5): {excellent}")
    print(f"Неуспевающие (средний балл ниже 3.0): {failing}")


def below_threshold(students):
    try:
        threshold = float(input("Порог среднего балла: ").replace(",", "."))
    except ValueError:
        print("Введите число.")
        return

    matches = []
    for student in students:
        average = student_average(student)
        if average is not None and average < threshold:
            matches.append((student, average))

    if not matches:
        print("Подходящих студентов нет.")
        return

    for student, average in sorted(matches, key=lambda item: item[1]):
        print(f"{student['name']} | группа: {student['group']} | средний балл: {average:.2f}")


def show_rating(students):
    graded = [(s, student_average(s)) for s in students if student_average(s) is not None]
    if not graded:
        print("Пока нет студентов с оценками.")
        return

    graded.sort(key=lambda item: item[1], reverse=True)
    print("\nРейтинг студентов:")
    for position, (student, average) in enumerate(graded, 1):
        print(f"{position}. {student['name']} — {average:.2f} ({student['group']})")


def main():
    students = load_students()
    actions = {
        "1": lambda: add_student(students),
        "2": lambda: show_students(students),
        "3": lambda: search_student(students),
        "4": lambda: add_grade(students),
        "5": lambda: show_student_grades(students),
        "6": lambda: group_analytics(students),
        "7": lambda: below_threshold(students),
        "8": lambda: show_rating(students),
    }

    while True:
        print(
            "\n=== Учёт успеваемости студентов ===\n"
            "1. Добавить студента\n"
            "2. Показать список студентов\n"
            "3. Найти студента по имени\n"
            "4. Добавить оценку\n"
            "5. Посмотреть оценки студента\n"
            "6. Статистика группы\n"
            "7. Студенты ниже порога\n"
            "8. Рейтинг студентов\n"
            "0. Выход"
        )
        choice = input("Выберите пункт: ").strip()

        if choice == "0":
            save_students(students)
            print("Данные сохранены. До свидания!")
            break
        action = actions.get(choice)
        if action:
            action()
        else:
            print("Нет такого пункта меню.")


if __name__ == "__main__":
    main()
